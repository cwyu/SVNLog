#!/usr/bin/env python
'''
svnplot-js.py
Copyright (C) 2009 Nitin Bhide (nitinbhide@gmail.com)

This module is part of SVNPlot (http://code.google.com/p/svnplot) and is released under
the New BSD License: http://www.opensource.org/licenses/bsd-license.php
--------------------------------------------------------------------------------------
'''
from svnplotjs import *

if( __name__ == "__main__"):
    RunMain()
    
